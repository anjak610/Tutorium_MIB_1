package Aufgabe_8;

public class Liste {

	public int element;
	public Liste nachfolger;

	public Liste(int w) {
		element = w;
		nachfolger = null;

	}

	public void hinzuf�gen(int w) {
		// int laenge = 1;
		if (nachfolger == null) {
			nachfolger = new Liste(w);
		} else {
			nachfolger.hinzuf�gen(w);
			// laenge++;
		}
	}

	public void entfernen() {
		if (nachfolger.nachfolger == null) {
			nachfolger = null;
		} else {
			nachfolger.entfernen();
		}
	}

	public int counter(int i) {
		if (nachfolger == null) {
			i++;
			return i;
		} else {
			i++;
			return nachfolger.counter(i);
		}
	}

	public int laenge() {
		int laenge = 0;

		laenge = counter(laenge);

		return laenge;
	}

	public String Ausgabe(String str) {
		if (nachfolger == null) {
			str = str + element;
			return str;
		} else {
			str = str + element + ",";
			return nachfolger.Ausgabe(str);
		}
	}

	public String toString() {
		String str = "";

		str = Ausgabe(str);

		return str;
	}
	
	public int sumUp(int sum) //
	{		
		if(nachfolger == null)// wieso ist beim ersten mal nicht schon schluss weil bei 3 is nachfolger gleich 0 ???
		{
			sum = sum + element;
			return sum;
		}
		else
		{
			sum = sum +element;
			return nachfolger.sumUp(sum);
		}
	}
	public int summe()
	{
		int summe = 0;		
		summe = sumUp(summe);
		return summe;
	}
	
	public int addiere(int result)
	{	  
	  
	  if ( nachfolger == null)
		{
			element = result + element;
			return element;
		}
		else 
		{
			element = result + element;
			System.out.println(element);
			return nachfolger.addiere(result);
		}	  
	}
	

}
