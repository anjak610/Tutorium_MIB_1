package Aufgabe9_2;

public class Personenliste {
	

}
