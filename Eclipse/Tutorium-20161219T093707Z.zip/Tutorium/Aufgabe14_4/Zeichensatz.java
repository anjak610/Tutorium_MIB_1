package Aufgabe14_4;

public class Zeichensatz {
	
	public static void main (String[]args)
	{
		int a = 1;
		int b = 200;
		zeichenTabelle(a,b);
	}
	
	public static void zeichenTabelle(int a, int b)	
	{
		for(int i = a; i <=b ; i++)
		{
			int x = i;		
			System.out.println(x + "\t" + (char) x + "\t" + Integer.toString(x,2) + "\t" + Integer.toString(x,16));
			
		}
			
	}

}



