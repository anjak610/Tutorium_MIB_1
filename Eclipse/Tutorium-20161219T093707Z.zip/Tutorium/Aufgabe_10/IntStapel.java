package Aufgabe_10;

public class IntStapel {

}
