package Examples;

public class Return {
	
	private static int energy = 5;
	
	public static void main(String[]args)
	{
		
	}
	
	public static int getEnergy ()
	{
		
		return energy;
	}

}
