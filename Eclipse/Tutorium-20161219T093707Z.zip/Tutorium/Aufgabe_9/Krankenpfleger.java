package Aufgabe_9;

public class Krankenpfleger extends Mitarbeiter {
	
	Person a = new Person();
	
	public String anrede()
	{
		if (super.geschlecht == true ) {
			return ("Krankenschwester " + super.vorname + super.nachname);
		}
		
		if (super.geschlecht == false ) {
			return ("Krankenpfleger " + super.vorname + super.nachname);
		}		
		else
			return null;	

	}
	
	public String formloseAnrede()
	{
	  a.geschlecht = geschlecht; 
	  a.vorname = vorname; 
	  a.nachname= nachname;
	  return a.anrede();
	}

}
