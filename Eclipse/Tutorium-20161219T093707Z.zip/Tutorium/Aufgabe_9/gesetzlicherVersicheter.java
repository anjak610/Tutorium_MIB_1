package Aufgabe_9;

public class gesetzlicherVersicheter extends Kunde {
	
	public String Krankenkasse;

}
