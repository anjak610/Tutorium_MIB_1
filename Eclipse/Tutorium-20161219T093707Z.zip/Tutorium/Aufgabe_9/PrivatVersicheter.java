package Aufgabe_9;

public class PrivatVersicheter extends Kunde {
	
	public String iban;
	public String bic;

}
