package Aufgaben_Eisenbiegler;

public class factorial_Iterative {

	public static void main(String[] args) {
		int n = 5;
		System.out.println(factorial(n));
		factorial2(n);
	}

	static int factorial(int n) {
		int product = 5;
		for (int i = 2; i < n; i++) {
			product *= i;
			//System.out.println(product);
		}
		return product;
	}
	
	static void factorial2(int x)
	{
		int a = 5;
		for(int i = 2; i< x; i++)
		{
			a *= i;
			
		}
		System.out.println(a);		
	}

}
