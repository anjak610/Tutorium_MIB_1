
public class ToStringTest {

	public void main (String[] args)
	{
		String a;
		int x = 3;
		a = Integer.toString(x);
		System.out.println(a);
	}
}
